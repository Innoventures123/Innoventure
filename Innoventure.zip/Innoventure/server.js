const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));


mongoose.connect('mongodb://localhost/hrportal', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

const userSchema = new mongoose.Schema({
  name: String,
  idNumber: String,
  email: String,
  password: String,
});

// Hash the password before saving to the database
userSchema.pre('save', function (next) {
  const user = this;
  if (!user.isModified('password')) return next();

  bcrypt.genSalt(10, (err, salt) => {
    if (err) return next(err);

    bcrypt.hash(user.password, salt, (err, hash) => {
      if (err) return next(err);
      user.password = hash;
      next();
    });
  });
});

const User = mongoose.model('User', userSchema);

app.post('/login', (req, res) => {
  const { email, password } = req.body;
  User.findOne({ email }, (err, user) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (user) {
      bcrypt.compare(password, user.password, (err, result) => {
        if (err) {
          console.error(err);
          res.status(500).json({ error: 'Internal Server Error' });
        } else if (result) {
          res.json({ message: 'Login successful', user });
        } else {
          res.status(401).json({ error: 'Invalid credentials' });
        }
      });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  });
});

app.post('/signup', (req, res) => {
  const { name, idNumber, email, password } = req.body;
  const newUser = new User({ name, idNumber, email, password });

  newUser.save((err, user) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json({ message: 'Signup successful', user });
    }
  });
});

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/form.html');
});


app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
